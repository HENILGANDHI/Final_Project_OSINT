
from flask import Flask, render_template, jsonify, request
from db_handler import db, init_db, add_vulnerability, get_all_vulnerabilities

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///data.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

init_db(app)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/store', methods=['POST'])
def store_data():
    vulnerabilities = request.json.get('results', [])
    for item in vulnerabilities:
        add_vulnerability(item)
    return "Data stored successfully!"

@app.route('/fetch', methods=['GET'])
def fetch_data():
    records = get_all_vulnerabilities()
    data = [record.data for record in records]
    return jsonify(data)

if __name__ == "__main__":
    app.run(debug=True)
