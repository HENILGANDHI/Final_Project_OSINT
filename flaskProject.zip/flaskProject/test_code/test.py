from flask import Flask, render_template, jsonify
from db_handler import db, init_db, add_vulnerability, get_all_vulnerabilities, count_vulnerabilities
import requests
import time  # اضافه شده برای وقفه بین درخواست‌ها

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///data.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

base_url = "https://www.cvedetails.com/api/v1/vulnerability/search"
headers = {
    "Authorization": "Bearer f8741cc811e00fdd3805c4275db0e71e75f474b7.eyJzdWIiOjgzNzcsImlhdCI6MTczMjg1MzgxOCwiZXhwIjoxNzM1NjAzMjAwLCJraWQiOjEsImMiOiJNcEdPZWdsSmFURXB2QUE0UnRYWG9zS0MwWWJWb0N5Tkg5QklvTmxRR3hpY2VmRHpqaloxWk42blRDSkRHMzFRaDREYUR0dmMifQ==",
    "accept": "application/json"
}

init_db(app)

def fetch_data_cvsdetails():
    for year in range(2012, 2014):  # از سال 2012 تا 2022
        fetch_data_cvsdetails_tech(year, 1, 6)  # نیمه اول سال
        fetch_data_cvsdetails_tech(year, 7, 12)  # نیمه دوم سال


def fetch_data_cvsdetails_tech(year, start_month, end_month):
    with app.app_context():
        max_pages = 4
        page = 1
        while page <= max_pages:
            url = f"{base_url}?outputFormat=json&publishDateStart={year}-{'0' + str(start_month) if start_month < 10 else str(start_month)}-01&publishDateEnd={year}-{'0' + str(end_month) if end_month < 10 else str(end_month)}-01&pageNumber={page}&resultsPerPage=50"
            print(url)
            response = requests.get(url, headers=headers)
            if response.status_code == 200:
                data = response.json().get('results', [])
                if not data:
                    break
                for item in data:
                    add_vulnerability(item)
                page += 1
                time.sleep(2)
            elif response.status_code == 429:
                backoff_time = 10
                for retry in range(5):
                    print(f"Rate limit reached. Waiting for {backoff_time} seconds (attempt {retry + 1}).")
                    time.sleep(backoff_time)
                    response = requests.get(url, headers=headers)
                    if response.status_code == 200:
                        data = response.json().get('results', [])
                        if not data:
                            break
                        for item in data:
                            add_vulnerability(item)
                        page += 1
                        break
                    backoff_time *= 2
                else:
                    print(f"Max retries reached for page {page} in year {year}. Skipping...")
                    break
            else:
                print(f"Error fetching page {page} for {year}: {response.status_code}")
                break



def reset_database():
    with app.app_context():
        db.drop_all()
        db.create_all()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/fetch', methods=['GET'])
def fetch_data():
    records = get_all_vulnerabilities()
    data = [record.data for record in records]
    return jsonify(data)






@app.route('/count', methods=['GET'])
def count_records():
    return jsonify({"count": count_vulnerabilities()})




@app.route('/fetch-data', methods=['POST'])
def fetch_data_from_api():
    try:
        fetch_data_cvsdetails()
        return jsonify({"message": "Data fetched successfully!"}), 200
    except Exception as e:
        return jsonify({"message": f"Error fetching data: {e}"}), 500

if __name__ == "__main__":
    with app.app_context():
        reset_database()
    app.run(debug=True)














# کد جدید که صبر نمیکنه
def fetch_data_cvsdetails():
    for year in range(2012, 2017):
        fetch_data_cvsdetails_tech(year, 1, 6)
        fetch_data_cvsdetails_tech(year, 7, 12)



#Fetching Data from CVE
def fetch_data_cvsdetails_tech(year, start_month, end_month):
    with app.app_context():
        print("In fetch_data_cvsdetails_tech:")
        #for page in range(1, 3):  # Loop for up to 5 pages
        #url = f"{base_url}?outputFormat=json&publishDateStart={start_year}-0{start_month}-01&publishDateEnd={end_year}-0{end_month}-01&pageNumber={1}&resultsPerPage=50"
        url = f"{base_url}?outputFormat=json&publishDateStart={year}-{'0' + str(start_month) if start_month < 10 else str(start_month)}-01&publishDateEnd={year}-{'0' + str(end_month) if end_month < 10 else str(end_month)}-01&pageNumber={1}&resultsPerPage=50"
        print(url)  # Debugging: print the URL being requested
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            data = response.json().get('results', [])
            for item in data:
                print(item)
                add_vulnerability(item)










#کد قدیمی م

def fetch_data_cvsdetails():
    for year in range(2012, 2014): 
        fetch_data_cvsdetails_tech(year, 1, 6)  
        fetch_data_cvsdetails_tech(year, 7, 12) 


def fetch_data_cvsdetails_tech(year, start_month, end_month):
    with app.app_context():
        max_pages = 4
        page = 1
        while page <= max_pages:
            url = f"{base_url}?outputFormat=json&publishDateStart={year}-{'0' + str(start_month) if start_month < 10 else str(start_month)}-01&publishDateEnd={year}-{'0' + str(end_month) if end_month < 10 else str(end_month)}-01&pageNumber={page}&resultsPerPage=50"
            print(url)
            response = requests.get(url, headers=headers)
            if response.status_code == 200:
                data = response.json().get('results', [])
                if not data:
                    break
                for item in data:
                    add_vulnerability(item)
                page += 1
                time.sleep(2)
            elif response.status_code == 429:
                backoff_time = 2
                for retry in range(5):
                    print(f"Rate limit reached. Waiting for {backoff_time} seconds (attempt {retry + 1}).")
                    time.sleep(backoff_time)
                    response = requests.get(url, headers=headers)
                    if response.status_code == 200:
                        data = response.json().get('results', [])
                        if not data:
                            break
                        for item in data:
                            add_vulnerability(item)
                        page += 1
                        break
                    backoff_time *= 1.2
                else:
                    print(f"Max retries reached for page {page} in year {year}. Skipping...")
                    break
            else:
                print(f"Error fetching page {page} for {year}: {response.status_code}")
                break




